import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface District {
  id: string;
  state: string;
  district_name: string;
  created_at: string;
}

export interface Submission {
  id: string;
  district_id: string;
  image_url: string;
  description: string;
  contributor_name: string;
  contributor_contact: string | null;
  latitude: number | null;
  longitude: number | null;
  status: 'pending' | 'approved' | 'rejected';
  admin_notes: string | null;
  submitted_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  created_at: string;
  districts?: District;
}

export interface CoverageStats {
  id: string;
  district_id: string;
  total_submissions: number;
  approved_count: number;
  pending_count: number;
  rejected_count: number;
  last_updated: string;
  districts?: District;
}
